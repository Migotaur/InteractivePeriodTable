package com.example.thebestnotesapp2

class MainActivityModel {

    lateinit var mNote: Note

    fun setNote(note: Note){
        mNote = note
    }

    fun getNote():Note{
        return mNote
    }

}