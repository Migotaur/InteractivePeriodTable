package com.example.thebestnotesapp2

class MainActivityPresenter(mainActivityModel: MainActivityModel) :MainActivityContract.Presenter{
    lateinit var mView:MainActivityContract.View
    lateinit var mModel:MainActivityModel

    init {
        mModel = mainActivityModel
    }

    override fun setView(view: MainActivityContract.View) {
        mView = view
        mView.setPresenter(this)

    }

    override fun start() {
        mModel.setNote(Note("Hello World!"))
        mView.setTextView(mModel.getNote().getText())
    }
}