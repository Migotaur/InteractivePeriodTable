package com.example.thebestnotesapp2

interface MainActivityContract {
    interface View{
        fun setPresenter(presenter:MainActivityContract.Presenter)
        fun setTextView(text:String)
    }

    interface Presenter{
        fun setView(view:MainActivityContract.View)
        fun start()
    }
}